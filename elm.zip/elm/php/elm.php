<?php
/**
 * @Author: Marte
 * @Date:   2018-10-12 21:30:31
 * @Last Modified by:   Marte
 * @Last Modified time: 2018-10-12 22:09:18
 */
    $con = mysql_connect("localhost", "root", root) ;
    mysql_select_db("biaodan");
    mysql_query("SET NAMES UTF8");


    class loginAction extends Action {
        /*
        注册

         */
        public function register_do(){

            $data['phone'] = $_GET['phone_data'];
            $data['password'] = md5($_GET['password_data']);
            $data['time'] = time();
            $re = M('user')->add($data);
            echo $re;
        }

    }

?>